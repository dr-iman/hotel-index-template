import menuData from '../data/menu-data.js';

class RestaurantMenu {
  constructor() {
    this.currentDay = 'saturday';
    this.init();
  }

  init() {
    this.renderDays();
    this.renderMenu();
    this.addEventListeners();
  }

  renderDays() {
    const daysContainer = document.querySelector('.day-selector');
    daysContainer.innerHTML = menuData.days.map(day => `
      <button class="day-btn ${day.active ? 'active' : ''}"
              data-day="${day.id}"
              aria-label="منوی ${day.name}">
        <i class="fas fa-calendar-day"></i>
        <span>${day.name}</span>
      </button>
    `).join('');
  }

  renderMenu() {
    const menuContainer = document.querySelector('.menu-container');
    const dayItems = menuData.items[this.currentDay];

    menuContainer.innerHTML = menuData.categories.map(category => {
      if (!dayItems[category.id]) return '';

      return `
        <div class="menu-category ${category.id}">
          <h2 class="category-title">
            <i class="fas fa-${category.icon}"></i>
            ${category.name}
          </h2>

          ${dayItems[category.id].map(item => `
            <div class="menu-item" data-id="${item.id}">
              <div class="item-info">
                <h3>${item.name}</h3>
                <p>${item.description}</p>
              </div>
              <span class="price">${item.price.toLocaleString()} تومان</span>
            </div>
          `).join('')}
        </div>
      `;
    }).join('');
  }

  addEventListeners() {
    document.querySelectorAll('.day-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        this.currentDay = btn.dataset.day;
        this.updateActiveDay(btn);
        this.renderMenu();
      });
    });
  }

  updateActiveDay(activeBtn) {
    document.querySelectorAll('.day-btn').forEach(btn => {
      btn.classList.remove('active');
    });
    activeBtn.classList.add('active');
  }
}

new RestaurantMenu();
