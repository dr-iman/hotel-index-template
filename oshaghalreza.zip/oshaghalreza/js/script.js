document.addEventListener('DOMContentLoaded', () => {
  const mainBtns = document.querySelectorAll('.glass-btn[data-tab]');
  const tabContents = document.querySelectorAll('.tab-content');
  const container = document.querySelector('.container');
  const backBtns = document.querySelectorAll('.back-btn');
  const dayButtons = document.querySelectorAll('.day-btn');

  // نمایش خودکار صفحه اصلی
  container.style.display = 'flex';

  // مدیریت تغییر تب‌ها
  mainBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const tabId = btn.getAttribute('data-tab');
      container.style.opacity = '0';

      setTimeout(() => {
        container.style.display = 'none';
        const targetTab = document.getElementById(tabId);
        targetTab.style.display = 'block';

        setTimeout(() => {
          targetTab.style.opacity = '1';
          targetTab.scrollTop = 0;
        }, 50);
      }, 300);
    });
  });

  // مدیریت دکمه برگشت
  backBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const currentTab = btn.closest('.tab-content');
      currentTab.style.opacity = '0';

      setTimeout(() => {
        currentTab.style.display = 'none';
        container.style.display = 'flex';

        setTimeout(() => {
          container.style.opacity = '1';
        }, 50);
      }, 300);
    });
  });

  // مدیریت فرم تماس
  const contactForm = document.querySelector('.contact-form form');
  if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();

      const name = e.target.querySelector('input[type="text"]').value;
      const message = e.target.querySelector('textarea').value;

      if (!name || !message) {
        alert('لطفاً نام و پیام را وارد کنید');
        return;
      }

      alert(`پیام شما با موفقیت ارسال شد!\nنام: ${name}\nپیام: ${message}`);
      contactForm.reset();
    });
  }

  // تشخیص دستگاه
  function checkDevice() {
    const isMobile = window.innerWidth <= 992;
    document.body.classList.toggle('mobile-view', isMobile);

    const tabContent = document.querySelector('.tab-content.active');
    if (tabContent) {
      tabContent.style.overflow = isMobile ? 'auto' : 'hidden';
    }
  }

  // اجرای اولیه و رصد تغییر سایز
  checkDevice();
  window.addEventListener('resize', checkDevice);
});
