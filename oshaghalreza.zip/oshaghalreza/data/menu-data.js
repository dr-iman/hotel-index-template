const menuData = {
  // روزهای هفته
  days: [
    { id: 'saturday', name: 'شنبه', active: true },
    { id: 'sunday', name: 'یکشنبه' },
    { id: 'monday', name: 'دوشنبه' },
    { id: 'tuesday', name: 'سه‌شنبه' },
    { id: 'wednesday', name: 'چهارشنبه' },
    { id: 'thursday', name: 'پنجشنبه' },
    { id: 'friday', name: 'جمعه' }
  ],

  // دسته‌بندی‌های منو
  categories: [
    { id: 'lunch', name: 'نهار', icon: 'lunch' },
    { id: 'dinner', name: 'شام', icon: 'dinner' }
  ],

  // آیتم‌های منو بر اساس روز
  items: {
    saturday: {
      lunch: [
        { id: 1, name: ' چلو کباب ', description: ' چلو کباب کوبیده به همراه برنج ایرانی درجه یک ', price: 85000 },
        { id: 2, name: ' چلو جوجه ', description: ' چلو جوجه کباب به همراه برنج ایرانی ', price: 95000 },
        { id: 3, name: ' رولت گوشت ', description: ' رولت گوشت درجه یک ', price: 85000 },
        { id: 4, name: ' خورشت کرفس ', description: ' خورشت کرفس به همراه برنج ایرانی ', price: 95000 }
      ],
      'dinner': [
        { id: 5, name: ' خوراک کباب کوبیده ', description: ' خوراک کباب کوبیده به گوشت گوسفندی ', price: 185000 },
        { id: 6, name: ' خوراک جوجه ', description: ' جوجه کباب درجه یک ', price: 150000 },
        { id: 7, name: ' رولت گوشت ', description: ' رولت گوشت درجه یک ', price: 185000 },
        { id: 8, name: ' ماکارانی ', description: ' ماکارانی درجه یک با گوشت چرخکرده ', price: 150000 },
        { id: 9, name: ' میرزا قاسمی ', description: ' میرزا قاسمی درجه یک ', price: 150000 }
      ]
    },
    sunday: {
      // ...
    }
    // سایر روزها
  }
};

export default menuData;
